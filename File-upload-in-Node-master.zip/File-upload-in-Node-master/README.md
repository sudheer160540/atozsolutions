File-upload-in-Node
===================

Download code and type 
```node Server.js``` 
Visit ```localhost:3000``` to view the app.

```Tutorial link``` : http://wp.me/p4ISPV-cq

